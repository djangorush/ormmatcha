from matcha.orm.meta import Model, CharField, IntField

class User(Model):
    id = IntField()
    first_name = CharField()
    last_name = CharField()
    password = CharField()

    def __str__(self):
        if None == self.id:
            return "Null"
        return '(' + self.id.__get__() + ') ' + self.first_name + ' ' +self.last_name 